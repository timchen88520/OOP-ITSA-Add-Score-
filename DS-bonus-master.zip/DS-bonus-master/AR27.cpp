#include<cstdio>  
#include<cstdlib>  
#include<cmath>  
#include<algorithm>  
#include<cstring>  
using namespace std;  
int main(){  
    int n;  
    while(scanf("%d",&n)!=EOF){  
        bool a[n+5];  
        memset(a,false,sizeof(a));  
        int t;  
        for(int i=0;i<n-1;i++){  
            scanf("%d",&t);  
            a[t]=true;  
        }  
        for(int i=1;i<=n;i++){  
            if(!a[i]){  
                printf("%d\n",i);  
                break;  
            }  
        }  
    }  
  
  
  
    return 0;  
}
