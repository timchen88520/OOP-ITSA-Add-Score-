#include<cstdio>  
#include<cstdlib>  
#include<cmath>  
#include<algorithm>  
#include<cstring>  
typedef long long lint;  
using namespace std;  
int main(){  
    int n;  
    while(scanf("%d",&n)!=EOF){  
        int t,sum=0;  
        for(int i=0;i<n;i++){  
            for(int j=0;j<n;j++){  
                scanf("%d",&t);  
                if(i==j) sum+=t;  
            }  
        }  
        printf("%d\n",sum);  
    }  
    return 0;  
}
