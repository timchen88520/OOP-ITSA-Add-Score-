#include<cstdio>  
#include<cstdlib>  
#include<cmath>  
#include<algorithm>  
#include<cstring>  
using namespace std;  
int main(){  
    char s[100];  
    while(scanf("%s",s)!=EOF){  
        int len=strlen(s);  
        for(int i=0;i<len;i++){  
            printf("%c",s[i]-3);  
        }  
        printf("\n");  
    }  
  
  
    return 0;  
} 
