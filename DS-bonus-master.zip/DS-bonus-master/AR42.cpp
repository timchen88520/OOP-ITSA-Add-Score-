#include<cstdio>  
#include<cstdlib>  
#include<cmath>  
#include<algorithm>  
#include<cstring>  
typedef long long lint;  
using namespace std;  
int main(){  
    int n;  
    int ma=-105,mi=105;  
    while(scanf("%d",&n)!=EOF){  
        ma=max(ma,n);  
        mi=min(mi,n);  
    }  
    printf("Largest number = %d\n",ma);  
    printf("Smallest number = %d\n",mi);  
    return 0;  
}
